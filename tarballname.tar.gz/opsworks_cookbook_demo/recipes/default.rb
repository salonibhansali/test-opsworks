Chef::Log.info("********** Hello, World! **********")
